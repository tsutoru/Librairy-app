/*
 * Copyright 2011-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.data.core;

import java.beans.Introspector;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jspecify.annotations.Nullable;

import org.springframework.util.Assert;
import org.springframework.util.ConcurrentReferenceHashMap;
import org.springframework.util.StringUtils;

/**
 * Abstraction of a {@link SimplePropertyPath} of a domain class.
 *
 * @author Oliver Gierke
 * @author Christoph Strobl
 * @author Mark Paluch
 * @author Mariusz Mączkowski
 * @author Johannes Englmeier
 */
class SimplePropertyPath implements PropertyPath {

	private static final String PARSE_DEPTH_EXCEEDED = "Trying to parse a path with depth greater than 1000; This has been disabled for security reasons to prevent parsing overflows";

	private static final String DELIMITERS = "_\\.";
	private static final Pattern SPLITTER = Pattern.compile("(?:[%s]?([%s]*?[^%s]+))".replaceAll("%s", DELIMITERS));
	private static final Pattern SPLITTER_FOR_QUOTED = Pattern.compile("(?:[%s]?([%s]*?[^%s]+))".replaceAll("%s", "\\."));
	private static final Pattern NESTED_PROPERTY_PATTERN = Pattern.compile("\\p{Lu}[\\p{Ll}\\p{Nd}]*$");
	private static final Map<Property, SimplePropertyPath> cache = new ConcurrentReferenceHashMap<>();

	private final TypeInformation<?> owningType;
	private final String name;
	private final TypeInformation<?> typeInformation;
	private final TypeInformation<?> actualTypeInformation;
	private final boolean isCollection;

	private @Nullable SimplePropertyPath next;

	/**
	 * Creates a leaf {@link SimplePropertyPath} (no nested ones) with the given name inside the given owning type.
	 *
	 * @param name must not be {@literal null} or empty.
	 * @param owningType must not be {@literal null}.
	 */
	SimplePropertyPath(String name, Class<?> owningType) {
		this(name, TypeInformation.of(owningType), Collections.emptyList());
	}

	/**
	 * Creates a leaf {@link SimplePropertyPath} (no nested ones with the given name and owning type.
	 *
	 * @param name must not be {@literal null} or empty.
	 * @param owningType must not be {@literal null}.
	 * @param base the {@link SimplePropertyPath} previously found.
	 */
	SimplePropertyPath(String name, TypeInformation<?> owningType, List<SimplePropertyPath> base) {

		Assert.hasText(name, "Name must not be null or empty");
		Assert.notNull(owningType, "Owning type must not be null");
		Assert.notNull(base, "Previously found properties must not be null");

		String decapitalized = Introspector.decapitalize(name);
		Property property = lookupProperty(owningType, decapitalized);

		if (property == null) {
			property = lookupProperty(owningType, StringUtils.uncapitalize(name));
		}

		if (property == null) {
			throw new PropertyReferenceException(decapitalized, owningType, base);
		}

		this.owningType = owningType;
		this.name = property.path;
		this.typeInformation = property.type;
		this.isCollection = this.typeInformation.isCollectionLike();
		this.actualTypeInformation = this.typeInformation.getActualType() == null ? this.typeInformation
				: this.typeInformation.getRequiredActualType();
	}

	private static @Nullable Property lookupProperty(TypeInformation<?> owningType, String name) {

		TypeInformation<?> propertyType = owningType.getProperty(name);

		return propertyType != null ? new Property(propertyType, name) : null;
	}

	@Override
	public TypeInformation<?> getOwningType() {
		return owningType;
	}

	@Override
	public String getSegment() {
		return name;
	}

	@Override
	public Class<?> getLeafType() {
		return getLeafProperty().getType();
	}

	@Override
	public Class<?> getType() {
		return this.actualTypeInformation.getType();
	}

	@Override
	public TypeInformation<?> getTypeInformation() {
		return this.typeInformation;
	}

	@Override
	public @Nullable SimplePropertyPath next() {
		return next;
	}

	@Override
	public boolean hasNext() {
		return next != null;
	}

	@Override
	public boolean isCollection() {
		return isCollection;
	}

	@Override
	public Iterator<PropertyPath> iterator() {

		return new Iterator<>() {

			private @Nullable SimplePropertyPath current = SimplePropertyPath.this;

			@Override
			public boolean hasNext() {
				return current != null;
			}

			@Override
			public @Nullable SimplePropertyPath next() {

				SimplePropertyPath result = current;

				if (result == null) {
					return null;
				}

				this.current = result.next();
				return result;
			}
		};
	}

	@Override
	public boolean equals(@Nullable Object o) {
		return PropertyPathUtil.equals(this, o);
	}

	@Override
	public int hashCode() {
		return PropertyPathUtil.hashCode(this);
	}

	/**
	 * Extracts the {@link SimplePropertyPath} chain from the given source {@link String} and {@link TypeInformation}.
	 * <br />
	 * Uses {@link #SPLITTER} by default and {@link #SPLITTER_FOR_QUOTED} for {@link Pattern#quote(String) quoted}
	 * literals.
	 * <p>
	 * Separate parts of the path may be separated by {@code "."} or by {@code "_"} or by camel case. When the match to
	 * properties is ambiguous longer property names are preferred. So for "userAddressCity" the interpretation
	 * "userAddress.city" is preferred over "user.address.city".
	 * </p>
	 *
	 * @param source a String denoting the property path, must not be {@literal null}.
	 * @param type the owning type of the property path, must not be {@literal null}.
	 * @return a new {@link SimplePropertyPath} guaranteed to be not {@literal null}.
	 */
	public static SimplePropertyPath from(String source, Class<?> type) {
		return from(source, TypeInformation.of(type));
	}

	/**
	 * Extracts the {@link SimplePropertyPath} chain from the given source {@link String} and {@link TypeInformation}.
	 * <br />
	 * Uses {@link #SPLITTER} by default and {@link #SPLITTER_FOR_QUOTED} for {@link Pattern#quote(String) quoted}
	 * literals.
	 * <p>
	 * Separate parts of the path may be separated by {@code "."} or by {@code "_"} or by camel case. When the match to
	 * properties is ambiguous longer property names are preferred. So for "userAddressCity" the interpretation
	 * "userAddress.city" is preferred over "user.address.city".
	 * </p>
	 *
	 * @param source a String denoting the property path, must not be {@literal null}.
	 * @param type the owning type of the property path, must not be {@literal null}.
	 * @return a new {@link SimplePropertyPath} guaranteed to be not {@literal null}.
	 */
	public static SimplePropertyPath from(String source, TypeInformation<?> type) {

		Assert.hasText(source, "Source must not be null or empty");
		Assert.notNull(type, "TypeInformation must not be null or empty");

		return cache.computeIfAbsent(new Property(type, source), it -> {

			List<String> iteratorSource = new ArrayList<>();

			Matcher matcher = isQuoted(it.path) ? SPLITTER_FOR_QUOTED.matcher(it.path.replace("\\Q", "").replace("\\E", ""))
					: SPLITTER.matcher("_" + it.path);

			while (matcher.find()) {
				iteratorSource.add(matcher.group(1));
			}

			Iterator<String> parts = iteratorSource.iterator();

			SimplePropertyPath result = null;
			Stack<SimplePropertyPath> current = new Stack<>();

			while (parts.hasNext()) {
				if (result == null) {
					result = create(parts.next(), it.type, current);
					current.push(result);
				} else {
					current.push(create(parts.next(), current));
				}
			}

			if (result == null) {
				throw new IllegalStateException(
						String.format("Expected parsing to yield a PropertyPath from %s but got null", source));
			}

			return result;
		});
	}

	private static boolean isQuoted(String source) {
		return source.matches("^\\\\Q.*\\\\E$");
	}

	/**
	 * Creates a new {@link SimplePropertyPath} as subordinary of the given {@link SimplePropertyPath}.
	 *
	 * @param source
	 * @param base
	 * @return
	 */
	private static SimplePropertyPath create(String source, Stack<SimplePropertyPath> base) {

		SimplePropertyPath previous = base.peek();

		SimplePropertyPath propertyPath = create(source, previous.typeInformation.getRequiredActualType(), base);
		previous.next = propertyPath;
		return propertyPath;
	}

	/**
	 * Factory method to create a new {@link SimplePropertyPath} for the given {@link String} and owning type. It will
	 * inspect the given source for camel-case parts and traverse the {@link String} along its parts starting with the
	 * entire one and chewing off parts from the right side then. Whenever a valid property for the given class is found,
	 * the tail will be traversed for subordinary properties of the just found one and so on.
	 *
	 * @param source
	 * @param type
	 * @return
	 */
	private static SimplePropertyPath create(String source, TypeInformation<?> type, List<SimplePropertyPath> base) {
		return create(source, type, "", base);
	}

	/**
	 * Tries to look up a chain of {@link SimplePropertyPath}s by trying the given source first. If that fails it will
	 * split the source apart at camel case borders (starting from the right side) and try to look up a
	 * {@link SimplePropertyPath} from the calculated head and recombined new tail and additional tail.
	 *
	 * @param source
	 * @param type
	 * @param addTail
	 * @return
	 */
	private static SimplePropertyPath create(String source, TypeInformation<?> type, String addTail,
			List<SimplePropertyPath> base) {

		if (base.size() > 1000) {
			throw new IllegalArgumentException(PARSE_DEPTH_EXCEEDED);
		}

		PropertyReferenceException exception = null;
		SimplePropertyPath current = null;

		try {

			current = new SimplePropertyPath(source, type, base);

			if (!base.isEmpty()) {
				base.get(base.size() - 1).next = current;
			}

			List<SimplePropertyPath> newBase = new ArrayList<>(base);
			newBase.add(current);

			if (StringUtils.hasText(addTail)) {
				current.next = create(addTail, current.actualTypeInformation, newBase);
			}

			return current;

		} catch (PropertyReferenceException e) {

			if (current != null) {
				throw e;
			}

			exception = e;
		}

		Matcher matcher = NESTED_PROPERTY_PATTERN.matcher(source);

		if (matcher.find() && matcher.start() != 0) {

			int position = matcher.start();
			String head = source.substring(0, position);
			String tail = source.substring(position);

			try {
				return create(head, type, tail + addTail, base);
			} catch (PropertyReferenceException e) {
				throw e.hasDeeperResolutionDepthThan(exception) ? e : exception;
			}
		}

		throw exception;
	}

	@Override
	public String toString() {
		return String.format("%s.%s", owningType.getType().getSimpleName(), toDotPath());
	}

	private static final class Property {

		private final TypeInformation<?> type;
		private final String path;

		private Property(TypeInformation<?> type, String path) {
			this.type = type;
			this.path = path;
		}

		@Override
		public boolean equals(@Nullable Object obj) {

			if (obj == this) {
				return true;
			}

			if (!(obj instanceof Property that)) {
				return false;
			}

			return Objects.equals(this.type, that.type) && Objects.equals(this.path, that.path);
		}

		@Override
		public int hashCode() {
			return Objects.hash(type, path);
		}

		@Override
		public String toString() {

			return "Key[" + "type=" + type + ", " + "path=" + path + ']';
		}
	}
}

/*
 * Logback: the reliable, generic, fast and flexible logging framework.
 * Copyright (C) 1999-2026, QOS.ch. All rights reserved.
 *
 * This program and the accompanying materials are dual-licensed under
 * either the terms of the Eclipse Public License v2.0 as published by
 * the Eclipse Foundation
 *
 *   or (per the licensee's choosing)
 *
 * under the terms of the GNU Lesser General Public License version 2.1
 * as published by the Free Software Foundation.
 */
package ch.qos.logback.classic.model;

import ch.qos.logback.core.model.ComponentModel;

public class ReceiverModel extends ComponentModel {

    private static final long serialVersionUID = -3161852321892056675L;

    @Override
    protected ReceiverModel makeNewInstance() {
        return new ReceiverModel();
    }
}

/**
 * The classes in this package make JNDI easier to use,
 * facilitating the accessing of configuration stored in JNDI,
 * and provide useful superclasses for JNDI access classes.
 *
 * <p>The classes in this package are discussed in Chapter 11 of
 * <a href="https://www.amazon.com/exec/obidos/tg/detail/-/0764543857/">Expert One-On-One J2EE Design and Development</a>
 * by Rod Johnson (Wrox, 2002).
 */
@NullMarked
package org.springframework.jndi;

import org.jspecify.annotations.NullMarked;
